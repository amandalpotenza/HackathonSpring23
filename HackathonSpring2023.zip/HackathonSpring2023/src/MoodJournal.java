import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class MoodJournal {
    
    private static String[] moods = {"Happy", "Sad", "Relaxed", "Excited", "Stressed", "Angry", "Confused", "Indifferent"};
    private static String[][] affirmations = {
            {"The point is not to pay back kindness but to pass it on.","Being happy never goes out of style.","Happiness depends upon ourselves.","What makes you happy doesn't need to make sense to others.","It's a good day to have a good day."},
            {"If all you did today was hold yourself together, I'm proud of you.","Healing is not linear.","You are not a drop in the ocean. You are an entire ocean in a drop.","Life isn't about waiting for the storm to pass, it's about learning to dance in the rain.","It is often in the darkest skies that we see the brightest stars."},
            {"It's all about finding the calm in the chaos.","The best cure for the body is the quiet mind.","Sometimes the most productive thing you can do is relax.","Take time to do what makes your soul happy.","Happiness is the art of relaxation."},
            {"Always believe that something wonderful is about to happen.","Grateful for where I'm at. Excited for where I'm going.","I choose to make the rest of my life, the best of my life.","Believe in yourself and you will be unstoppable.","It always seems impossible until it's done."},
            {"Worrying doesn't empty tomorrow of its sorrows; it empties today of its strengths.","You don't have to see the whole staircase, just take the first step.","Every moment is a fresh beginning.","Stress should be a powerful driving force, not an obstacle.","The time to relax is when you don't have time for it."},
            {"To be angry is to let others mistakes punish yourself.","If you are patient in one moment of anger, you will escape a hundred days of sorrow.","The greatest remedy for anger is delay.","Anger is a bad advisor.","ANGER IS ONE LETTER SHORT OF DANGER."},
            {"When you are confused and can not conclude, follow your instincts.","Confusion is the mother of new learning.","Confusion shows something inside you is waiting to be explored and discovered.","Part of being successful is about asking questions and listening to the answers.","I hear and I forget. I see and I remember. I do and I understand."},
            {"Do not go where the path may lead, go instead where there is no path and leave a trail.","You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose.","The only impossible journey is the one you never begin.","Live in the sunshine, swim the sea, drink the wild air.","Life itself is the most wonderful fairy tale."}
    };

    //The journal will hold mood entries for 365 days
    private static String[] moodEntries = new String[365];
    private static List<String> journalEntries = new ArrayList<>();


    private static int currentDay = LocalDate.now().getDayOfYear();
    private static Scanner scanner = new Scanner(System.in);
    private static Random random = new Random();
    private static int currentMood;

    public static void main(String[] args) {
        //Greet the user and briefly describe the program
		System.out.println("______________________________________________________");
		System.out.println(" *            *        * ");
		System.out.println("          *              ");
		System.out.println("    *               *    ");
		System.out.println("*             *         *");
		System.out.println("heyyy! welcome to your personal mood journal");
		System.out.println("   *            *        ");
		System.out.println("           *             ");
		System.out.println("    *              *     ");
		System.out.println(" *            *        * ");
		System.out.println("here you can journal, track your mood, goals, and even play some fun destress games");
		System.out.println("");
		
        while (true) {
            System.out.println("What would you like to do?");
            System.out.println("1. Record your current mood");
            System.out.println("2. View your previous mood entry");
            System.out.println("3. Journal");
            System.out.println("4. View past journal entries");
            System.out.println("5. Play a little game to destress!");
            System.out.println("6. Set goals");
        
            // Get user choice
            int choice = scanner.nextInt();
        
            if (choice == 1) {
                // The user picks their mood from the given list!
                System.out.println("How are you?");
                for (int i = 0; i < moods.length; i++) {
                    System.out.printf("%d. %s\n", i+1, moods[i]);
                    System.out.println("");
                }
        
                    System.out.print("Tell me how you're feeling today: ");
                    int moodOptions = scanner.nextInt() - 1;
        
                    if (moodOptions < 0 || moodOptions >= moods.length) {
                        System.out.println("Sorry! That's not a valid mood. Please try again.");
                        continue;
                    }
        
                    // Update the current mood and print a random affirmation
                    currentMood = moodOptions;
                    String affirmation = getRandomAffirmation(currentMood);
                    System.out.println(affirmation);
                    moodEntries[currentDay - 1] = String.valueOf(currentMood);
                    
                    } else if (choice == 2) {
                        // View past mood entries
                        for (int i = 0; i < moodEntries.length; i++) {
                            if (moodEntries[i] != null) {
                                System.out.printf("Day %d: %s\n", i+1, moods[Integer.parseInt(moodEntries[i])]);
                            }
                        }
                    } else if (choice == 3) {
                        System.out.println("Enter your journal entry:");
                        scanner.nextLine();
                        String entry = scanner.nextLine();
                        journalEntries.add(entry);
                        System.out.println("Journal entry added successfully!");
                        System.out.println("");


                    } else if (choice == 4) {
                        System.out.println("Here are your previous entries:");
                        for (String entry : journalEntries) {
                            System.out.println(entry);
                            System.out.println("");
                        }
                    
                    } else if (choice == 5) {
                        destressGame();
                    
                    } else if (choice == 6) {
                    goalMethod();
                    
                    
                    } else {
                        System.out.println("Sorry, that's not a valid choice. Please try again.");
                        continue;
                    }
                }   
}

    private static String getRandomAffirmation(int moodOptions) {
        String[] moodAffirmations = affirmations[moodOptions];
        int randomIndex = random.nextInt(moodAffirmations.length);
        return moodAffirmations[randomIndex];
    }

		public static void goalMethod() 
    {
      String fakeChoice;
      char realChoice;
      String goalTxt;
      String fakeAccom;
      char realAccom;
      boolean comp = false;
      GoalClass goal = null;
      int num = 0;
      GoalList goalList = new GoalList();

      do
      {
        boolean ok = false;
        System.out.println("Please choose one of the following:");
        System.out.println("1. Add new goal to list");
        System.out.println("2. Remove goal from list");
        System.out.println("3. Print entire list of goals");
        System.out.println("4. Print only completed goals");
        System.out.println("5. Print only incomplete goals");
        System.out.println("Press 'Q' to quit");

        fakeChoice = scanner.next().toUpperCase();
        realChoice = fakeChoice.charAt(0);

        switch(realChoice)
        {
        case '1':
          System.out.println("What is the goal?");
          goalTxt = scanner.next();
          System.out.println("Press 'C' if the goal is already accomplished.");
          fakeAccom = scanner.next().toUpperCase();
          realAccom = fakeAccom.charAt(0);
          if (realAccom == 'C')
            comp = true;
          goal = new GoalClass(goalTxt, comp);
          ok = goalList.addToList(goal);
          if (ok == true)
            System.out.println("The goal has been added");
          else System.out.println("Youve reached the max goal count: 50");
          break;
        case '2':
          System.out.println("Make sure you know the number of the goal you would like to remove.");
          System.out.println("This can be checked by printing out the goals.");
          System.out.println("Press 'C' to continue, press anything else to go back.");
          fakeAccom = scanner.next().toUpperCase();
          realAccom = fakeAccom.charAt(0);
          if (realAccom == 'C')
          {
            System.out.println("What is the number of the goal you would like to remove?");
            num = scanner.nextInt();
            ok = goalList.removeFromList(num);
            if (ok == true)
              System.out.println("The goal has been removed");
            else System.out.println("Nothing was removed");
          }
          break;
        case '3':
          //print entire list of goals
          goalList.printList();
          break;
        case '4':
          //print completed goals
          goalList.printIncomplete();
          break;
        case '5':
          //print incompleted goals
          goalList.printComplete();
          break;
        case 'Q':
          System.out.println("Quitting goals part.");
          break;
        default:
          System.out.println("Not an option, try again.");
        }

      }//do
      while (realChoice != 'Q');
    }

      public static void destressGame()
    {
      String yesOrNo = " ";

      System.out.println("This is Bob! He will be your pet! Help take care of him for a while! ");
      System.out.println();
      System.out.println(" =^._.^=");
      System.out.println("    (    )~");
      System.out.println("     || || ");
      System.out.println();

      //walkBob
      do
        {
        System.out.println("Would you like to walk Bob? Yes or No?");
        yesOrNo = scanner.next().toUpperCase();
        }
      while (!yesOrNo.equals("YES") && !yesOrNo.equals("NO"));

      if (yesOrNo.equals("YES"))
        walkBob();
      else System.out.print("Okay!");


      //feedBob
      do
        {
        System.out.println("Would you like to feed Bob? Yes or No?");
        yesOrNo = scanner.next().toUpperCase();
        System.out.println(yesOrNo);
        }
      while (!yesOrNo.equals("YES") && !yesOrNo.equals("NO"));

      if (yesOrNo.equals("YES"))
        feedBob();
      else System.out.print("Okay!");


      //playWithBob
      do
        {
        System.out.println("Would you like to play with Bob? Yes or No?");
        yesOrNo = scanner.next().toUpperCase();
        System.out.println(yesOrNo);
        }
      while (!yesOrNo.equals("YES") && !yesOrNo.equals("NO"));

      if (yesOrNo.equals("YES"))
        playWithBob();
      else System.out.print("Okay!");


      System.out.println("Thanks for playing with Bob! He thanks you for hanging with him! <3");

    }//destressGame	

  public static void walkBob()
    {
    String resume = " ";

      System.out.println("  O");
      System.out.println(" ||\\ _____  =^._.^=");
      System.out.println("  |       ~(    )  ");
      System.out.println(" / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("         O");
      System.out.println("        ||\\ _____  =^._.^=");
      System.out.println("         |       ~(    )  ");
      System.out.println("        / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("                O");
      System.out.println("               ||\\ _____  =^._.^=");
      System.out.println("                |       ~(    )  ");
      System.out.println("               / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("                       O");
      System.out.println("                      ||\\ _____  =^._.^=");
      System.out.println("                       |       ~(    )  ");
      System.out.println("                      / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("                              O");
      System.out.println("                             ||\\ _____  =^._.^=");
      System.out.println("                              |       ~(    )  ");
      System.out.println("                             / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("                                    O");
      System.out.println("                                   ||\\ _____  =^._.^=");
      System.out.println("                                    |       ~(    )  ");
      System.out.println("                                   / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();
    }//walkBob

  public static void feedBob()
    {
    String resume = " ";

      System.out.println();
      System.out.println(" =^._.^=");
      System.out.println("    (    )~     ");
      System.out.println("     || ||    \\_---_/");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println();
      System.out.println("    =^._.^=");
      System.out.println(" ~(    )");
      System.out.println("  || ||    \\_---_/");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println();
      System.out.println("            ");
      System.out.println("    ~(  =^._.^=   ");
      System.out.println("     || || \\_---_/");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println();
      System.out.println("            ");
      System.out.println("    ~(  =^.x.^=   ");
      System.out.println("     || || \\___-_/");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println();
      System.out.println("    =^._.^=");
      System.out.println(" ~(    )");
      System.out.println("  || ||    \\_____/");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println();
      System.out.println("    =^.ω.^=");
      System.out.println(" ~(    )");
      System.out.println("  || ||    \\_____/");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();
      }//feedBob


  public static void playWithBob()
    {
    String resume = " ";

      System.out.println("  O/o");
      System.out.println(" ||    =^._.^=");
      System.out.println("  |       (    )~  ");
      System.out.println(" / \\      || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\     =^._.^=");
      System.out.println("  |     ~(    )  ");
      System.out.println(" / \\    || ||                       o");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\            =^._.^=");
      System.out.println("  |            ~(    )  ");
      System.out.println(" / \\           /| /|                o");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\                   =^._.^=");
      System.out.println("  |                   ~(    )  ");
      System.out.println(" / \\                  |/ |/         o");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\                          ");
      System.out.println("  |                          ~( =^._.^=  ");
      System.out.println(" / \\                         |/ |/  o");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\               =^.o.^=");
      System.out.println("  |                   (    )~  ");
      System.out.println(" / \\                  /| /| ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\    ");
      System.out.println("  |      =^._.^=  )~  ");
      System.out.println(" / \\    o |/ |/ ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();

      System.out.println("  O");
      System.out.println(" ||\\    =^.ω.^= ");
      System.out.println("  |        (    )~  ");
      System.out.println(" / \\    o  || || ");
      System.out.println();
      System.out.println("press any letter to continue: ");
      resume = scanner.next();
      }//playWithBob
}

