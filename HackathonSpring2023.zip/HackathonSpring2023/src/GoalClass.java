public class GoalClass
{
	private String myGoal;
	private boolean myComplete;
	
	public GoalClass()
	{
		myGoal = "None";
		myComplete = false;
	}
	public GoalClass(String newGoal, boolean ifComplete)
	{
		myGoal = newGoal;
		myComplete = ifComplete;
	}
	
	public void setGoal(String newGoal)
	{
		myGoal = newGoal;
	}
	
	public void setComplete(boolean ifComplete)
	{
		myComplete = ifComplete;
	}
	
	public String getGoal()
	{
		return myGoal;
	}
	
	public boolean getComplete()
	{
		return myComplete;
	}
	
	public String toString()
	{
		String ans = "Goal: " + myGoal;
		ans += "\nCompleted: " + myComplete;
		
		return ans;
	}
}//GoalClass



	
	

