public class GoalList 
{
	private int mySize;
	private GoalClass[] myGoals;
	
	public GoalList()
	{
		int i = 0;
		myGoals = new GoalClass[50];
		for (i = 0; i < 50; i++)
			myGoals[i] = null;
		mySize = 0;
	}
	
	public int getSize()
	{
		return mySize;
	}
	
	public boolean addToList(GoalClass newGoal)
	{
		boolean success = false;
		if (mySize < myGoals.length)
		{
			myGoals[mySize] = newGoal;
			mySize++;
			success = true;
		}
		return success;
	}
	
	//remove based on number on list
	public boolean removeFromList(int target)
	{
		int i = 0;
		GoalClass remove = null;
		boolean success = false;
		
		remove = myGoals[target - 1];
		
		if (remove != null)
		{
			for (i = target; i < mySize; i++)
				myGoals[i] = myGoals[i - 1];
			mySize--;
			success = false;
		}
		
		return success;
	}
	
	public void printList()
	{
		int i = 0;
		
		for (i = 0; i < mySize; i++)
		{
			System.out.println((i + 1) + ") Goal #" + (i + 1) + ":");
			System.out.println(myGoals[i].toString());
		}
	}
	
	public void printComplete()
	{
		int i = 0;
		int num = 1;
		
		for (i = 0; i < mySize; i++)
			if (myGoals[i].getComplete() == true)
			{
				System.out.println(num + ") Goal #" + (i + 1) + ":");
				System.out.println(myGoals[i].toString());
				num++;
			}
	}
	
	public void printIncomplete()
	{
		int i = 0;
		int num = 1;
		
		for (i = 0; i < mySize; i++)
			if (myGoals[i].getComplete() == false)
			{
				System.out.println(num + ") Goal #" + (i + 1) + ":");
				System.out.println(myGoals[i].toString());
				num++;
			}
	}
	
}//GoalList