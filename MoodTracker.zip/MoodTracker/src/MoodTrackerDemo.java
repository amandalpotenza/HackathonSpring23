import java.util.*;

public class MoodTrackerDemo 
{
	
	static Scanner keyboard = new Scanner(System.in);

	public static void main(String[] args) 
	{
		// Declare variables
		String choice = "None";
		char firstLetterChoice;
		Journal days = new Journal();
		String entry = "none";
		String fakeChoice;
		char realChoice;
		String goalTxt;
		String fakeAccom;
		char realAccom;
		boolean comp = false;
		GoalList goal = null;
		int num = 0;
		
		//Greet the user and briefly describe the program
		System.out.println("______________________________________________________");
		System.out.println(" *            *        * ");
		System.out.println("          *              ");
		System.out.println("    *               *    ");
		System.out.println("*             *         *");
		System.out.println("heyyy! welcome to your personal journal");
		System.out.println("   *            *        ");
		System.out.println("           *             ");
		System.out.println("    *              *     ");
		System.out.println(" *            *        * ");
		System.out.println("here you can track your mood and goals, as well as play some destress games");
		System.out.println("first, write a letter from the menu and choose what do you want to do");
		
		do
		{
			System.out.println("______________________________________________________");
			System.out.println("Menu: ");
			System.out.println("C: Choose your mood");
			System.out.println("W: Write your thoughts about this day");
			System.out.println("G: Set your goals");
			System.out.println("P: play destress game");
      System.out.println("L: Look at previous entries and moods");
			System.out.println("Q: Quit");
			
			System.out.println("Enter your choice: ");
			choice = keyboard.next();
			firstLetterChoice = choice.toUpperCase().charAt(0);
			switch(firstLetterChoice)
			{
			case 'C':
				//call a Choosemood method
				break;
			case 'W':
      	System.out.println("This is a freewrite section! Talk about anything (what you had for breakfast, the happenings of your day, what is exciting you, etc.) : ");
				entry = keyboard.next();
				days.setMyFreewriting(entry);
      	//create a new Journal object and set myFreewritting
				break;
			case 'G':
				do
				{
					boolean ok = false;
					System.out.println("Please choose one of the following:");
					System.out.println("1. Add new goal to list");
					System.out.println("2. Remove goal from list");
					System.out.println("3. Edit goal in list");
					System.out.println("4. Print entire list of goals");
					System.out.println("5. Print only completed goals");
					System.out.println("6. Print only incomplete goals");
					System.out.println("Press 'Q' to quit");
					
					fakeChoice = keyboard.next().toUpperCase();
					realChoice = fakeChoice.charAt(0);
					
					switch(realChoice)
					{
					case '1':
						System.out.println("What is the goal?");
						goalTxt = keyboard.next();
						System.out.println("Press 'C' if the goal is already accomplished.");
						fakeAccom = keyboard.next().toUpperCase();
						realAccom = fakeAccom.charAt(0);
						if (realAccom == 'C')
							comp = true;
						goal = new GoalList(goalTxt, comp);
						ok = GoalList.addToList(goal);
						if (ok == true)
							System.out.println("The goal has been added");
						else System.out.println("Youve reached the max goal count: 50");
						break;
					case '2':
						System.out.println("Make sure you know the number of the goal you would like to remove.");
						System.out.println("This can be checked by printing out the goals.");
						System.out.println("Press 'C' to continue, press anything else to go back.");
						fakeAccom = keyboard.next().toUpperCase();
						realAccom = fakeAccom.charAt(0);
						if (realAccom == 'C')
						{
							System.out.println("What is the number of the goal you would like to remove?");
							num = keyboard.nextInt();
							ok = GoalList.removeFromList(num);
							if (ok == true)
								System.out.println("The goal has been removed");
							else System.out.println("Nothing was removed");
						}
						break;
					case '3':
						break;
					case '4':
						break;
					case '5':
						break;
					case '6':
						break;
					case 'Q':
						System.out.println("Quitting goals part.");
						break;
					default:
						System.out.println("Not an option, try again.");
					}
					
				}//do
				while (realChoice != 'Q');
				break;
			case 'P':
				break;
      case 'L':
		    System.out.print(days.toString());
				break;
			case 'Q':
				break;
			default:
				System.out.println("Invalid choice. Try again!");
			}//switch
						
			}//do
			while (firstLetterChoice != 'Q');

	}//main

}//MoodTrackerDemo

            System.out.println("Do you want to genarate some things you can do based on your mood? (Y/N)");
			ans = keyboard.next();
            firstLetterAns = ans.toUpperCase().charAt(0);
            
            if (firstLetterAns == 'Y')
            switch (currentMood) 
    		{
    	    case '0':  // Happy
    	        System.out.println("1) Smile to 5 strangers");
    	        System.out.println("2) Reach out to someone you love and tell them how much you appreciate them");
    	        System.out.println("3) Write in alphabetical order everything you love");
    	        break;
    	    case '1':  // Sad 
    	    	System.out.println("1) Go for a date with yourself (if the weather is nice, enjoy it outside)");
    	    	System.out.println("2) Reach out to a friend or family member and talk about how you're feeling");
    	    	System.out.println("3) Do something kind for someone else, such as volunteering or sending a thoughtful message");
    	        break;
    	    case '2':  // Relaxed
    	    	System.out.println("1) Spend some time in quiet meditation or mindfulness practice");
    	    	System.out.println("2) Take a break from technology and spend time in nature or with a good book");
    	    	System.out.println("3) Practice deep breathing exercises to further relax your mind and body");
    	        break;
    	    case '3':  // Excited
    	    	System.out.println("1) Set a goals to transform your excitement into productive work.");
    	    	System.out.println("2) Make plans to do something fun or adventurous with friends or loved ones");
    	    	System.out.println("3) Take some time to reflect on why you're feeling excited and what you're looking forward to");
    	        break;
    	    case '4':  // Confused
    	    	System.out.println("1) Take a step back and try to identify the source of your confusion");
    	    	System.out.println("2) Research the topic you're confused about to gain more clarity");
    	    	System.out.println("3) Talk to someone you trust and ask for their perspective or advice");
    	        break;
    	    case '5':  // Stressed
    	    	System.out.println("1) Play our desstress game!");
    	    	System.out.println("2) Do some physical activities, such as yoga or hiking");
    	    	System.out.println("3) Practice positive self-talk and remind yourself that you can handle the situation");
    	        break;
    	    case '6':  // Angry
    	    	System.out.println("1) Take a break and remove yourself from the situation that's making you angry");
    	    	System.out.println("2) Practice deep breathing or other relaxation techniques to calm yourself down");
    	    	System.out.println("3) Once you're calm, try to identify the root cause of your anger and address it in a constructive way");
    	        break;
    	    case '7': //Indifferent
    	    	System.out.println("1) Listen to music and try to ");
    	    	System.out.println("2) Plan some adventure with your friends");
    	    	System.out.println("3) ");
    	    default: 
    	    	System.out.println("Unfortunatelly, I do not know your mood to generate ideas :(");
    		}//switch
            
            else if (firstLetterAns == 'N')
            	System.out.println("Thats fine! you can continue using journal or set your own goal by choosing this option in the menu");
        }//while
        
        
        
    }//main 




}//MoodTrackerDemo
