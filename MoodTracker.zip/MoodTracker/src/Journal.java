public class Journal {

    private String myMood;
    private String myFreewriting;

  public Journal(String mood, String freewriting)
    {
    myMood = mood;
    myFreewriting = freewriting;
    }//full

  public Journal()
    {
    myMood = "none";
    myFreewriting = "none";
    }//null

  //declare getters and setters
  public void setMyMood(String mood)
    {
    myMood = mood;
    }//setMyName

  public void setMyFreewriting(String freewriting)
    {
    myFreewriting = freewriting;
    }//setMyName

  public String getMyMood()
    {
    return myMood;
    }//getMyMood

  public String getMyFreewriting()
    {
    return myFreewriting;
    }//getMyFreewriting

  
  public String toString()
    {
    String ans = "This day, you felt " + myMood + ".\n";
    ans += "This was your freewrite: " + myFreewriting + "\n";

    return ans;
	}//toString
}//Journal